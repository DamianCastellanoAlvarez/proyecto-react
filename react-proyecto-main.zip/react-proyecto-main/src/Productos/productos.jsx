
const stock = [
    { name: ' Yerba', 
    price: " $500", 
    descripcion: "DIGESTIVO - ANALGESICO - ANSIOLÍTICO", 
    img:'https://i.imgur.com/AWUS8Ym.jpg', 
    id: 1, 
    detalle:"Cada amanecer es maravilloso. Tiene el brillo de una sonrisa, la frescura del amor y aires de esperanza. Es una invitación a vivir, a luchar por los sueños pendientes, a intentarlo de nuevo. Con nuestro blend te invitamos a vivir esta experiencia de Amanecer en cualquier momento, cada vez que necesitemos amanecer para continuar el día con toda la fuerza Ingredientes: Te verde, jengibre y manzana. Beneficios generales. Recuerda que nuestros productos no son medicamentos. Tienen propiedades saludables pero no son remedios. Si crees que puede ayudarte con una patología consulta con tu médico. No debe usarse en el embarazo o lactancia, ni en niños menores de un año. No consumir en exceso. Cómo consumir Jengibre. En hojas: se usan como té o se mezclan con otras hierbas como endulzante. En polvo: se agrega cucharaditas, agregar de a poco e ir probando el sabor. Puedes hervir agua y apagar antes de añadir las hojas de stevia, dejar reposar por 5 minutos , en recipiente tapado. Evita hervir la hoja de stevia porque perderá todas sus propiedades. Para una taza utilice un puñado (con los dedos) o 1 gramo de hoja seca para unos 125 ml de agua aproximadamente (1 taza). Si desea endulzar el agua del mate se puede preparar para el agua del termo (1 litro) con 4 gramos de hoja de stevia (4 puñados) aproximadamente, cantidad dependiendo el gusto de cada persona. Después de reposar el agua , colar y colocar en el termo. O sumarle al mate un puñado de hojas antes de colocar la yerba. Una tercera opción es poner cucharadas de stevia en polvo en el mate. También puedes prepararla como infusión. A la stevia en polvo la puedes usar en comidas"

},

    { name: ' Stevia', 
    price: " $300", 
    descripcion: "Antidiabética - Antioxidante - Antitumoral", 
    img:'https://i.imgur.com/y34PFWv.jpg', 
    id: 2,
    detalle:''
},
    { name: ' Te', 
    price: " $400", 
    descripcion: "Te verde - Manzanilla - Flor de Calendula", 
    img:'https://i.imgur.com/3CCfonZ.jpg', 
    id: 3,
    detalle:''
},
];


export default stock;